Commission Breakdown HTML snapshot is the visual specification, not the native renderer. Its external icon/font URLs may require network access. Download links in this snapshot are not part of the native demo.
SHA-256: 446610dc86fa95ae3a70f9ee39e5b2aac18e4b891fe3f9c326eb82d7bc26d867
