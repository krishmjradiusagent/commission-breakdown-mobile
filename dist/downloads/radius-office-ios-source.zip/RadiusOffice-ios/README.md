# Radius Office — SwiftUI developer preview

Requires iOS 17+, Swift 5.9+, and Xcode with an iOS SDK. Genuine SwiftUI; no WebView.

1. Unzip. In your Xcode app, Add Package Dependencies > Add Local; select this folder.
2. Link the `RadiusOffice` product to your app target.
3. Present `RadiusOfficeView(snapshot: yourSnapshot, fontName: yourRegisteredMonaSansName, onAction: handler)` in an existing NavigationStack or hosting controller.
4. Route actions to existing host editors/services; replace the snapshot after server success.
5. For a standalone demo, create an iOS App project, add this local package, replace the generated App entry point with `Examples/DemoApp.swift`, and run on a simulator. Do not retain two @main entry points.

The demo reports action callbacks; it does not save fees or connect to a backend. Read STATUS.md before integration. HTML reference and tokens are included under reference/.
